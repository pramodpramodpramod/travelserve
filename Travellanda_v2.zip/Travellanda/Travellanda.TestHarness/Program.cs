﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Travellanda;

namespace Travellanda.TestHarness
{
    class Program
    {
        static void Main(string[] args)
        {

            var req = new Schema.Countries.Request();
            req.Head = new Schema.Countries.RequestHead()
            {
                Password = "feLXshUzTQMb",
                Username = "c725cc388dee5db313d6a9584d4950a9"
            };
            req.Body = new Schema.Countries.RequestBody();
            var gen = new ApiCall<Schema.Countries.Request, Schema.Countries.Response>();
            var res = gen.Submit(req);
            foreach (var country in res.Body.Countries)
            {
                Console.WriteLine(country.CountryCode + "-" + country.CountryName);
            }



            var cityRequest = new Schema.Cities.Request();
            cityRequest.Head = new Schema.Cities.RequestHead()
            {
                Password = "feLXshUzTQMb",
                Username = "c725cc388dee5db313d6a9584d4950a9"
            };
            cityRequest.Body = new Schema.Cities.RequestBody()
            {
                CountryCode = "GB"
            };
            var cGen = new ApiCall<Schema.Cities.Request, Schema.Cities.Response>();
            var cRes = cGen.Submit(cityRequest);
            foreach (var item in cRes.Body.Countries)
            {
                foreach (var city in item.Cities)
                {
                    Console.WriteLine($"{city.CityId}--{city.CityName}");
                }
            }


            //273524 = Crawley
            var hotelListReq = new Schema.Hotels.Request();
            hotelListReq.Head = new Schema.Hotels.RequestHead()
            {
                Password = "feLXshUzTQMb",
                Username = "c725cc388dee5db313d6a9584d4950a9"
            };
            hotelListReq.Body = new Schema.Hotels.RequestBody()
            {
                ItemElementName = Schema.Hotels.ItemChoiceType.CityId,
                Item = "273524"
            };
            var gg = new ApiCall<Schema.Hotels.Request, Schema.Hotels.Response>();
            var hResp = gg.Submit(hotelListReq);
            foreach(var item in hResp.Body.Hotels)
            {
                Console.WriteLine($"{item.HotelId} -=- {item.HotelName}");
            }


            //



        }
    }
}