﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Travellanda;

namespace Travellanda.TestHarness
{
    class Program
    {
        static void Main(string[] args)
        {
            Travellanda.AutoMapperConfig.Init();
            var manager = new TravellandaManager();
            //var result = manager.GetAllCities("GB");
            //foreach (var city in result.Countries.First().Cities)
            //{
            //    Console.WriteLine($"{city.CityId} - {city.CityName}");
            //}
            //var result = manager.GetAllCountries(); //304668-brighton
            //foreach(var country in result.Countries)
            //{
            //    Console.WriteLine($"{country.CountryCode}--{country.CountryName}-{country.Currency}");
            //}

            //var result = manager.GetHotels(304668);
            //foreach (var hotel in result.Hotels) //1989602-hilton metropole
            //{
            //    Console.WriteLine($"{hotel.HotelId}--{hotel.HotelName}");
            //}

            //var req = new Schema.Countries.Request();
            //req.Head = new Schema.Countries.RequestHead()
            //{
            //    Password = "feLXshUzTQMb",
            //    Username = "c725cc388dee5db313d6a9584d4950a9"
            //};
            //req.Body = new Schema.Countries.RequestBody();
            //var gen = new ApiCall<Schema.Countries.Request, Schema.Countries.Response>();
            //var res = gen.Submit(req);
            //foreach (var country in res.Body.Countries)
            //{
            //    Console.WriteLine(country.CountryCode + "-" + country.CountryName);
            //}


            var result = manager.GetHotelDetails(new List<string> { "1989602" });
            foreach(var hotel in result.Hotels)
            {
                Console.WriteLine($"{hotel.Description}");
                Console.WriteLine($"**FAcilities");
                foreach (var facitlity in hotel.Facilities)
                {
                    Console.WriteLine($"{facitlity.FacilityName} - {facitlity.FacilityType}");
                }
                Console.WriteLine($"**Images");
                foreach (var image in hotel.Images)
                {
                    Console.WriteLine($"{image}");
                }
            }
        }
    }
}