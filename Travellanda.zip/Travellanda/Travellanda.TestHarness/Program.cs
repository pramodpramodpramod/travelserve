﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Travellanda;
using TravelServe.Abstracts;
using TravelServe.BaseClasses;

namespace Travellanda.TestHarness
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Init configs..");
            Travellanda.AutoMapperConfig.Init();
            IHotelManager manager = new TravellandaManager();
            Console.WriteLine("done");

            //get all countires
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Get all countries");
            Console.ForegroundColor = ConsoleColor.Gray;
            var allCounturesResult = manager.GetAllCountries(); //304668-brighton
            foreach (var country in allCounturesResult.Countries)
            {
                Console.WriteLine($"{country.CountryCode}--{country.CountryName}-{country.Currency}");
            }

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Get all cities in GB");
            Console.ForegroundColor = ConsoleColor.Gray;
            var result1 = manager.GetAllCities("GB");
            foreach (var city in result1.Countries.First().Cities)
            {
                Console.WriteLine($"{city.CityId} - {city.CityName}");
            }

            //Hotel Details
            var hotelId = "1989602";
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"getting details of a Hilton in Brighton:{hotelId}");
            Console.ForegroundColor = ConsoleColor.Gray;
            var hotelDetailsResult = manager.GetHotelDetails(new List<string> { hotelId });
            foreach (var hotel in hotelDetailsResult.Hotels)
            {
                Console.WriteLine($"{hotel.Description}");
                Console.WriteLine($"**FAcilities");
                foreach (var facitlity in hotel.Facilities)
                {
                    Console.WriteLine($"{facitlity.FacilityName} - {facitlity.FacilityType}");
                }
                Console.WriteLine($"**Images");
                foreach (var image in hotel.Images)
                {
                    Console.WriteLine($"{image}");
                }
            }

            //HotelSearch
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Search hotels in in cities ");
            Console.ForegroundColor = ConsoleColor.Gray;
            var searchRequest = new HotelSearchRequest()
            {
                AvailableOnly = 1,
                //HotelId = 1989602,
                //HotelIds = new List<int> { 1989602 },
                CityIds = new List<int> { 304668, 129552 }, //brighton, aberdeen
                //CityId = 304668,
                CheckInDate = DateTime.Now.AddDays(10),
                CheckOutDate = DateTime.Now.AddDays(12),
                Currency = "GBP",
                Nationality = "GB",
                Rooms = new List<Room>() { new Room() { NumAdults = 1, Children = new List<int> { 10 } } }
            };
            var searchResult = manager.SearchHotels(searchRequest);
            var optionId = searchResult.Hotels.First().Options.First().OptionId;
            var roomId = searchResult.Hotels.First().Options.First().Rooms.First().RoomId;
            foreach (var item in searchResult.Hotels)
            {
                Console.WriteLine($"  ** {item.HotelName}");
                foreach (var option in item.Options)
                {
                    Console.WriteLine($"     --{option.TotalPrice} - {option.BoardType} -- {option.OptionId}");
                }
            }


            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"get policies for option :{optionId}");
            Console.ForegroundColor = ConsoleColor.Gray;
            var policyResult = manager.GetHotelPolicies(optionId);
            Console.WriteLine($"Currency:{ policyResult.Currency}  Cancel By: {policyResult.CancellationDeadline}  TotalPrice: {policyResult.TotalPrice}");
            foreach (var item in policyResult.Policies)
            {
                Console.WriteLine($"  From: {item.From}  Type: {item.Type}  Value: {item.Value}");
            }
            foreach (var item in policyResult.Alerts)
            {
                Console.WriteLine($"  Alert: {item}");
            }
            foreach (var item in policyResult.Restrictions)
            {
                Console.WriteLine($"  Restriction: {item}");
            }

            ////booking
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"book room for option :{optionId}");
            Console.ForegroundColor = ConsoleColor.Gray;
            var adultName = new AdultName() { FirstName = "Angel", Title = "Mr", LastName = "Superior" };
            var childName = new ChildName() { FirstName = "Mini", LastName = "Superior" };
            var paxName = new PaxNames() { AdultName = new List<AdultName>() { adultName }, ChildName = new List<ChildName>() { childName } };
            var rooms = new List<RoomRequest>();
            var roomReq = new RoomRequest()
            {
                PaxNames = paxName,
                RoomId = roomId
            };
            var bookingRequest = new HotelBookingRequest()
            {
                OptionId = optionId,
                YourReference = "ABCDE123123",
                Rooms = new List<RoomRequest>() { roomReq }
            };
            var bookingResult = manager.BookHotel(bookingRequest);
            Console.WriteLine($"status { bookingResult.BookingStatus }  BookingRef: {bookingResult.BookingReference} YourRef: {bookingResult.YourReference} Currency:{bookingResult.Currency}, TotalPrioce {bookingResult.TotalPrice}");


            //booking details
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"get booking details for date range");
            Console.ForegroundColor = ConsoleColor.Gray;
            var detailsRequest = new HotelBookingDetailsRequest();
            detailsRequest.BookingDates = new BookingDates() { BookingDateEnd = DateTime.Now, BookingDateStart = DateTime.Now.AddDays(-2) };
            //detailsRequest.BookingReference = bookingRef;
            var bookingDetails = manager.GetHotelBookingDetails(detailsRequest);
            Console.WriteLine($"Found:{bookingDetails.BookingsFound} Returned:{bookingDetails.BookingsReturned}");
            foreach (var booking in bookingDetails.Bookings)
            {
                Console.WriteLine($"{booking.BookingReference} Leader:{booking.LeaderName} -- In:{booking.CheckInDate} Out:{booking.CheckOutDate}");
                foreach (var room in booking.Rooms)
                {
                    Console.WriteLine($"{room.RoomName} Adults:{room.NumAdults} Child: {room.NumChildren}");
                }
            }

            //cancel booking
            var bookingRef = "asdfasdf";// bookingDetails.Bookings.First().BookingReference; //first in the list
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"cancel booking {bookingRef}");
            Console.ForegroundColor = ConsoleColor.Gray;
            var cancelBooking = manager.CancelHotelBooking(bookingRef);
            Console.WriteLine($" ## Cancelled: Ref:{cancelBooking.BookingReference}  Status:{cancelBooking.BookingStatus} RequestSTatuc: {cancelBooking.RequestStatus ?? "NA"} ");
        }
    }
}