﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Travellanda.Schema;
using TravelServe.BaseClasses;

namespace Travellanda
{
    internal class ApiCall<Req, Res> where Req: class where Res : class
    {
        private Res postXMLData(string destinationUrl, string requestXml)
        {
            try
            {

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(destinationUrl);
                byte[] bytes;
                bytes = Encoding.ASCII.GetBytes(requestXml);
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                request.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip,deflate");
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Close();
                HttpWebResponse response;
                response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var stream = response.GetResponseStream();
                    var xmlReader = XmlReader.Create(stream);
                    var ser = new XmlSerializer(typeof(Res));
                    var obj = (Res)ser.Deserialize(xmlReader);
                    return obj;
                }
                return null;
            }catch(Exception ex)
            {
                throw new ServiceException("An error while posting XML data to Travellanda servvice", ex);
            }
        }

        public Res Submit(Req xmlObject)
        {
            try
            {
                var url = "http://xmldemo.travellanda.com/xmlv1";
                xmlObject = FormatHead(xmlObject);
                var postData = SerializeFromObjectToString(xmlObject);
                var result = postXMLData(url, postData);
                //result = FormatResponseHead(result);
                return result;
            }
            catch(Exception ex)
            {
                throw new ServiceException("An error while posting XML data to Travellanda servvice", ex);
            }
        }

        private string SerializeFromObjectToString(Req xmlObject)
        {
            if (xmlObject == null)
            {
                return string.Empty;
            }
            try
            {
                var xmlserializer = new XmlSerializer(typeof(Req));
                var stringWriter = new StringWriter();
                var settings = new XmlWriterSettings();
                settings.OmitXmlDeclaration = true;
                using (var writer = XmlWriter.Create(stringWriter, settings))
                {
                    xmlserializer.Serialize(writer, xmlObject);
                    return $"xml={stringWriter.ToString()}";
                }
            }
            catch (Exception ex)
            {
                throw new ServiceException("An error while serializing xmlObject to string", ex);
            }
        }

        private Req FormatHead(Req xmlObject)
        {
            //get type of the Head property from the requested object and create new instance 
            var head = typeof(Req).GetProperty("Head", BindingFlags.Instance | BindingFlags.Public);
            var requestHead = Activator.CreateInstance(head.PropertyType);
            //to the newly created instance of head populate the username and password properties
            var userNamePoperty = requestHead.GetType().GetProperty("Username", BindingFlags.Instance | BindingFlags.Public);
            userNamePoperty.SetValue(requestHead, "c725cc388dee5db313d6a9584d4950a9");
            var passowordProperty = requestHead.GetType().GetProperty("Password", BindingFlags.Instance | BindingFlags.Public);
            passowordProperty.SetValue(requestHead, "feLXshUzTQMb");

            //get the Head property of the req object and assign to its head the newly created instance of head
            var headProperty = xmlObject.GetType().GetProperty("Head", BindingFlags.Instance | BindingFlags.Public);
            headProperty.SetValue(xmlObject, requestHead);
            return xmlObject;
        }
    }
}
