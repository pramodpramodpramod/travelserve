﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Travellanda.Schema;
using TravelServe.BaseClasses;

namespace Travellanda
{
    public static class AutoMapperConfig
    {
        public static void Init()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile(new AllProfile());
            });
        }
    }

    public class AllProfile : Profile
    {
        public AllProfile()
        {
            //cities- response 
            CreateMap<Schema.Cities.ResponseBody, Cities>();
            CreateMap<Schema.Cities.ResponseBodyCountry, Country>();
            CreateMap<Schema.Cities.ResponseBodyCountryCity, City>();
            CreateMap<Schema.Cities.ResponseBodyError, Error>();
            CreateMap<Schema.Cities.ResponseHead, Head>();

            //country- response 
            CreateMap<Schema.Countries.ResponseBody, Countrys>();
            CreateMap<Schema.Countries.ResponseBodyCountry, Country>();
            CreateMap<Schema.Countries.ResponseBodyError, Error>();
            CreateMap<Schema.Countries.ResponseHead, Head>();

            //get hotels- response 
            CreateMap<Schema.Hotels.ResponseBody, LocationHotels>();
            CreateMap<Schema.Hotels.ResponseBodyHotel, LocationHotel>();
            CreateMap<Schema.Hotels.ResponseBodyError, Error>();
            CreateMap<Schema.Hotels.ResponseHead, Head>();

            //hotel details- response 
            CreateMap<Schema.HotelDetails.ResponseBody, HotelDetails>();
            CreateMap<Schema.HotelDetails.ResponseBodyHotel, Hotel>();
            CreateMap<Schema.HotelDetails.ResponseBodyHotelFacility, Facility>();
            CreateMap<Schema.HotelDetails.ResponseBodyError, Error>();
            CreateMap<Schema.HotelDetails.ResponseHead, Head>();

            ////hotel search
            //request
            CreateMap<HotelSearchRequest , Schema.HotelSearch.RequestBody>();
            CreateMap<Room, Schema.HotelSearch.RequestBodyRoom>();
            CreateMap<Room, Schema.HotelSearch.RequestBody>();
            //CreateMap<HotelIds, Schema.HotelSearch.RequestBodyHotelIds>();
            //CreateMap<CityIds, Schema.HotelSearch.RequestBodyCityIds>();
            //response
            CreateMap<Schema.HotelSearch.ResponseBody, HotelSearch>();
            CreateMap<Schema.HotelSearch.ResponseBodyHotel, Hotel>();
            CreateMap<Schema.HotelSearch.ResponseBodyHotelOption, Option>();
            CreateMap<Schema.HotelSearch.ResponseBodyHotelOptionRoom, Room>();
            CreateMap<Schema.HotelSearch.ResponseBodyError, Error>();
            CreateMap<Schema.HotelSearch.ResponseHead, Head>();


            ///hotel policy - response 
            CreateMap<Schema.HotelPolicies.ResponseBody, HotelPolicies>();
            CreateMap<Schema.HotelPolicies.ResponseBodyPolicy, Policy>();
            CreateMap<Schema.HotelPolicies.ResponseHead, Head>();

            ////hotel booking 
            //request
            CreateMap<HotelBookingRequest, Schema.HotelBooking.RequestBody>();
            CreateMap<RoomRequest, Schema.HotelBooking.RequestBodyRoom>();
            CreateMap<PaxNames, Schema.HotelBooking.RequestBodyRoomPaxNames>();
            CreateMap<AdultName, Schema.HotelBooking.RequestBodyRoomPaxNamesAdultName>();
            CreateMap<ChildName, Schema.HotelBooking.RequestBodyRoomPaxNamesChildName>();
            // response 
            CreateMap<Schema.HotelBooking.ResponseBodyHotelBooking, HotelBooking>();
            CreateMap<Schema.HotelBooking.ResponseBodyError, Error>();
            CreateMap<Schema.HotelBooking.ResponseHead, Head>();


            //hotel booking details
            //request
            CreateMap<HotelBookingDetailsRequest, Schema.HotelBookingDetails.RequestBody>();
            CreateMap<BookingDates, Schema.HotelBookingDetails.RequestBodyBookingDates>();
            CreateMap<CheckInDates, Schema.HotelBookingDetails.RequestBodyCheckInDates>();
            //resposne
            CreateMap<Schema.HotelBookingDetails.ResponseBody, HotelBookingDetails>();
            CreateMap<Schema.HotelBookingDetails.ResponseBodyHotelBooking, HotelBooking >();
            CreateMap<Schema.HotelBookingDetails.ResponseBodyHotelBookingPolicy, Policy>();
            CreateMap<Schema.HotelBookingDetails.ResponseBodyHotelBookingRoom, Room>();
            CreateMap<Schema.HotelBookingDetails.ResponseBodyError, Error>();
            CreateMap<Schema.HotelBookingDetails.ResponseHead, Head>();


            //cancel booking
            //resposne
            CreateMap<Schema.HotelBookingCancel.ResponseBodyHotelBooking, HotelBookingCancel>();
            CreateMap<Schema.HotelBookingCancel.ResponseBodyError, Error>();
            CreateMap<Schema.HotelBookingCancel.ResponseHead, Head>();

        }
    }
}
