﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Travellanda.Schema;
using TravelServe.BaseClasses;

namespace Travellanda
{
    public static class AutoMapperConfig
    {
        public static void Init()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile(new AllProfile());
            });
        }
    }

    public class AllProfile : Profile
    {
        public AllProfile()
        {
            //cities
            CreateMap<Schema.Cities.ResponseBody, Cities>();
            CreateMap<Schema.Cities.ResponseBodyCountry, Country>();
            CreateMap<Schema.Cities.ResponseBodyCountryCity, City>();

            //country
            CreateMap<Schema.Countries.ResponseBody, Countrys>();
            CreateMap<Schema.Countries.ResponseBodyCountry, Country>();

            //get hotels
            CreateMap<Schema.Hotels.ResponseBody, LocationHotels>();
            CreateMap<Schema.Hotels.ResponseBodyHotel, LocationHotel>();

            //hotel details
            CreateMap<Schema.HotelDetails.ResponseBody, HotelDetails>();
            CreateMap<Schema.HotelDetails.ResponseBodyHotel, Hotel>();
            CreateMap<Schema.HotelDetails.ResponseBodyHotelFacility, Facility>();

            ////hotel search
            //request
            CreateMap<HotelSearchRequest , Schema.HotelSearch.RequestBody>();
            CreateMap<Room, Schema.HotelSearch.RequestBodyRoom>();
            CreateMap<HotelIds, Schema.HotelSearch.RequestBodyHotelIds>();
            CreateMap<CityIds, Schema.HotelSearch.RequestBodyCityIds>();
            //response
            CreateMap<Schema.HotelSearch.ResponseBody, HotelSearch>();
            CreateMap<Schema.HotelSearch.ResponseBodyCityIds, CityIds>();
            CreateMap<Schema.HotelSearch.ResponseBodyHotel, Hotel>();
            CreateMap<Schema.HotelSearch.ResponseBodyHotelOption, Option>();
            CreateMap<Schema.HotelSearch.ResponseBodyHotelOptionRoom, Room>();

        }
    }
}
