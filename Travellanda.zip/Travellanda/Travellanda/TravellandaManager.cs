﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelServe.Abstracts;
using TravelServe.BaseClasses;
using TravelServe.BaseClasses.Request;

namespace Travellanda
{
    public class TravellandaManager : IHotelManager
    {
        public Cities GetAllCities(string countryCode)
        {
            var req = new Schema.Cities.Request();
            req.Body = new Schema.Cities.RequestBody()
            {
                CountryCode = countryCode
            };
            var gen = new ApiCall<Schema.Cities.Request, Schema.Cities.Response>();
            var res = gen.Submit(req);
            var cities = Mapper.Map<Cities>(res.Body);
            return cities;
        }

        public Countrys GetAllCountries()
        {
            var req = new Schema.Countries.Request();
            req.Body = new Schema.Countries.RequestBody();
            var gen = new ApiCall<Schema.Countries.Request, Schema.Countries.Response>();
            var res = gen.Submit(req);
            var countries = Mapper.Map<Countrys>(res.Body);
            return countries;
        }

        public LocationHotels GetHotels(string countryCode)
        {
            var req = new Schema.Hotels.Request();
            req.Body = new Schema.Hotels.RequestBody()
            {
                ItemElementName = Schema.Hotels.ItemChoiceType.CountryCode,
                Item = countryCode
            };
            return GetLocationHotels(req);
        }
        public LocationHotels GetHotels(int cityId)
        {
            var req = new Schema.Hotels.Request();
            req.Body = new Schema.Hotels.RequestBody()
            {
                ItemElementName = Schema.Hotels.ItemChoiceType.CityId,
                Item = cityId.ToString()
            };
            return GetLocationHotels(req);
        }

        private LocationHotels GetLocationHotels(Schema.Hotels.Request request)
        {
            var gen = new ApiCall<Schema.Hotels.Request, Schema.Hotels.Response>();
            var res = gen.Submit(request);
            var hotels = Mapper.Map<LocationHotels>(res.Body);
            return hotels;
        }


        public HotelDetails GetHotelDetails(IEnumerable<string> hotelIds)
        {
            var req = new Schema.HotelDetails.Request();
            req.Body = new Schema.HotelDetails.RequestBody()
            {
                HotelIds = hotelIds.ToArray()
            };
            var gen = new ApiCall<Schema.HotelDetails.Request, Schema.HotelDetails.Response>();
            var res = gen.Submit(req);
            var hotelDetails = Mapper.Map<HotelDetails>(res.Body);
            return hotelDetails;
        }


        public HotelSearch SearchHotels()
        {

        }


    }



}
