﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelServe.Abstracts;
using TravelServe.BaseClasses;
using TravelServe.BaseClasses.Request;

namespace Travellanda
{
    public class TravellandaManager : IHotelManager
    {
        public Cities GetAllCities(string countryCode)
        {
            var req = new Schema.Cities.Request();
            req.Body = new Schema.Cities.RequestBody()
            {
                CountryCode = countryCode
            };
            var gen = new ApiCall<Schema.Cities.Request, Schema.Cities.Response>();
            var res = gen.Submit(req);
            var cities = Mapper.Map<Cities>(res.Body);
            return cities;
        }

        public Countrys GetAllCountries()
        {
            var req = new Schema.Countries.Request();
            req.Body = new Schema.Countries.RequestBody();
            var gen = new ApiCall<Schema.Countries.Request, Schema.Countries.Response>();
            var res = gen.Submit(req);
            var countries = Mapper.Map<Countrys>(res.Body);
            return countries;
        }

        public LocationHotels GetHotels(string countryCode)
        {
            var req = new Schema.Hotels.Request();
            req.Body = new Schema.Hotels.RequestBody()
            {
                ItemElementName = Schema.Hotels.ItemChoiceType.CountryCode,
                Item = countryCode
            };
            return GetLocationHotels(req);
        }
        public LocationHotels GetHotels(int cityId)
        {
            var req = new Schema.Hotels.Request();
            req.Body = new Schema.Hotels.RequestBody()
            {
                ItemElementName = Schema.Hotels.ItemChoiceType.CityId,
                Item = cityId.ToString()
            };
            return GetLocationHotels(req);
        }

        private LocationHotels GetLocationHotels(Schema.Hotels.Request request)
        {
            var gen = new ApiCall<Schema.Hotels.Request, Schema.Hotels.Response>();
            var res = gen.Submit(request);
            var hotels = Mapper.Map<LocationHotels>(res.Body);
            return hotels;
        }


        public HotelDetails GetHotelDetails(IEnumerable<string> hotelIds)
        {
            var req = new Schema.HotelDetails.Request();
            req.Body = new Schema.HotelDetails.RequestBody()
            {
                HotelIds = hotelIds.ToArray()
            };
            var gen = new ApiCall<Schema.HotelDetails.Request, Schema.HotelDetails.Response>();
            var res = gen.Submit(req);
            var hotelDetails = Mapper.Map<HotelDetails>(res.Body);
            return hotelDetails;
        }

        public HotelSearch SearchHotels(HotelSearchRequest hotelSearchRequest)
        {
            var req = new Schema.HotelSearch.Request();
            var body = Mapper.Map<Schema.HotelSearch.RequestBody>(hotelSearchRequest);
            req.Body = body;

            //populate item and itemtype based on whats requested.
            //prefernce order - HotelId, CityId, HotelIds, CityIds  (atleast one of this has to be requested as per API)
            req.Body.ItemElementName =
                      hotelSearchRequest.HotelId > 0 ? Schema.HotelSearch.ItemChoiceType.HotelId :
                      hotelSearchRequest.CityId > 0 ? Schema.HotelSearch.ItemChoiceType.CityId :
                      hotelSearchRequest.HotelIds != null && hotelSearchRequest.HotelIds.Any() ? Schema.HotelSearch.ItemChoiceType.HotelIds :
                      Schema.HotelSearch.ItemChoiceType.CityIds;

            switch (req.Body.ItemElementName)
            {
                case Schema.HotelSearch.ItemChoiceType.HotelId:
                    req.Body.Item = hotelSearchRequest.HotelId.ToString();
                    break;
                case Schema.HotelSearch.ItemChoiceType.CityId:
                    req.Body.Item = hotelSearchRequest.CityId.ToString();
                    break;
                case Schema.HotelSearch.ItemChoiceType.HotelIds:
                    var hotelIds= new Schema.HotelSearch.RequestBodyHotelIds();
                    hotelIds.HotelId = hotelSearchRequest.HotelIds.Select(i => i.ToString()).ToArray();
                    req.Body.Item = hotelIds;
                    break;
                default:
                    var cityIds = new Schema.HotelSearch.RequestBodyCityIds();
                    cityIds.CityId = hotelSearchRequest.CityIds.Select(i => i.ToString()).ToArray();
                    req.Body.Item = cityIds;
                    break;
            }
            var gen = new ApiCall<Schema.HotelSearch.Request, Schema.HotelSearch.Response>();
            var res = gen.Submit(req);
            var hotelDetails = Mapper.Map<HotelSearch>(res.Body);
            return hotelDetails;
        }

        public HotelPolicies GetHotelPolicies(string optionId)
        {
            var req = new Schema.HotelPolicies.Request();
            req.Body = new Schema.HotelPolicies.RequestBody() { OptionId = optionId };
            var gen = new ApiCall<Schema.HotelPolicies.Request, Schema.HotelPolicies.Response>();
            var res = gen.Submit(req);
            var hotelPolicies = Mapper.Map<HotelPolicies>(res.Body);
            return hotelPolicies;
        }

        public HotelBooking BookHotel(HotelBookingRequest bookingRequest)
        {
            var req = new Schema.HotelBooking.Request();
            req.Body = Mapper.Map<Schema.HotelBooking.RequestBody>(bookingRequest);
            var gen = new ApiCall<Schema.HotelBooking.Request, Schema.HotelBooking.Response>();
            var res = gen.Submit(req);
            var hotelBooking = Mapper.Map<HotelBooking>(res.Body.HotelBooking);
            return hotelBooking;
        }


        public HotelBookingDetails GetHotelBookingDetails(HotelBookingDetailsRequest detailsRequest)
        {
            var req = new Schema.HotelBookingDetails.Request();
            req.Body = Mapper.Map<Schema.HotelBookingDetails.RequestBody>(detailsRequest);
            var gen = new ApiCall<Schema.HotelBookingDetails.Request, Schema.HotelBookingDetails.Response>();
            var res = gen.Submit(req);
            var hotelBookingDetails = Mapper.Map<HotelBookingDetails>(res.Body);
            return hotelBookingDetails;
        }

        public HotelBookingCancel CancelHotelBooking(string bookingRefernce)
        {
            var req = new Schema.HotelBookingCancel.Request();
            req.Body = new Schema.HotelBookingCancel.RequestBody() { BookingReference = bookingRefernce };
            var gen = new ApiCall<Schema.HotelBookingCancel.Request, Schema.HotelBookingCancel.Response>();
            var res = gen.Submit(req);
            var hotelBookingCancel = Mapper.Map<HotelBookingCancel>(res.Body);
            return hotelBookingCancel;
        }


    }
}
