﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelServe.BaseClasses;

namespace TravelServe.Abstracts
{
    public interface IHotelManager
    {
        HotelBooking BookHotel(HotelBookingRequest bookingRequest);
        HotelBookingCancel CancelHotelBooking(string bookingRefernce);
        Cities GetAllCities(string countryCode);
        Countrys GetAllCountries();
        HotelBookingDetails GetHotelBookingDetails(HotelBookingDetailsRequest detailsRequest);
        HotelDetails GetHotelDetails(IEnumerable<string> hotelIds);
        HotelPolicies GetHotelPolicies(string optionId);
        LocationHotels GetHotels(int cityId);
        LocationHotels GetHotels(string countryCode);
        HotelSearch SearchHotels(HotelSearchRequest hotelSearchRequest);
    }
}
