﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelServe.BaseClasses;
using TravelServe.BaseClasses.Request;

namespace TravelServe.Abstracts
{
    public interface IHotelManager
    {
        Countrys GetAllCountries();
        Cities GetAllCities(string countryCode);
        LocationHotels GetHotels(string countryCode);
        LocationHotels GetHotels(int cityCode);
    }
}
