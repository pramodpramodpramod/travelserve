﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelServe.BaseClasses
{
    public class Countrys 
    {
        public int CountriesReturned { get; set; }
        public IEnumerable<Country> Countries { get; set; }
        public Error Error { get; set; }
        public Head Head { get; set; }

    }

    public class Country
    {
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string Currency { get; set; }
        public IEnumerable<City> Cities { get; set; }
    }

    public class Cities 
    {
        public int CitiesReturned { get; set; }
        public IEnumerable<Country> Countries { get; set; }
        public Error Error { get; set; }
        public Head Head { get; set; }
    }

    public class City
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
        public string StateCode { get; set; }
        public string CityCode { get; set; }
    }


    public class LocationHotels 
    {
        public int HotelsReturned { get; set; }
        public IEnumerable<LocationHotel> Hotels { get; set; }
        public Error Error { get; set; }
        public Head Head { get; set; }
    }
    public class LocationHotel
    {
        public int HotelId { get; set; }
        public int CityId { get; set; }
        public string CityCode { get; set; }
        public string HotelName { get; set; }
        public string CountryCode { get; set; }
    }
    

    public class HotelDetails 
    {
        public int HotelsReturned { get; set; }
        public IEnumerable<Hotel> Hotels { get; set; }

        public Error Error { get; set; }
        public Head Head { get; set; }
    }

    public class Hotel
    {
        //public int HotelId { get; set; }
        public string HotelName { get; set; }
        public decimal StarRating { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public string Address { get; set; }
        public string Location { get; set; }
        public string PhoneNumber { get; set; }
        public string Description { get; set; }
        public IEnumerable<Facility> Facilities { get; set; }
        public IEnumerable<string> Images { get; set; }
        public IEnumerable<Option> Options { get; set; }
    }

    public class Facility
    {
        public string FacilityType { get; set; }
        public string FacilityName { get; set; }
    }


    public class Option
    {
        public string OptionId { get; set; }
        public int OnRequest { get; set; }
        public string BoardType { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal DiscountApplied { get; set; }
        public string DealName { get; set; }
        public IEnumerable<Room> Rooms { get; set; }
    }

    public class Room
    {
        public string RoomId { get; set; }
        public string RoomName { get; set; }
        public int NumAdults { get; set; }
        public int NumChildren { get; set; }
        public decimal RoomPrice { get; set; }
        public IEnumerable<decimal> DailyPrices { get; set; }
        public IEnumerable<int> Children { get; set; }
    }

    public class Children
    {
        public IEnumerable<int> ChildAge { get; set; }
    }

    public class HotelSearch
    {
        public IEnumerable<int> CityIds { get; set; }
        public IEnumerable<int> HotelIds { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public string Nationality { get; set; }
        public string Currency { get; set; }
        public int HotelsReturned { get; set; }
        public IEnumerable<Hotel> Hotels { get; set; }
        public Error Error { get; set; }
        public Head Head { get; set; }
    }


    public class HotelPolicies 
    {
        public string OptionId { get; set; }
        public string Currency { get; set; }
        public decimal TotalPrice { get; set; }
        public DateTime CancellationDeadline { get; set; }
        public IEnumerable<Policy> Policies { get; set; }
        public IEnumerable<string> Restrictions { get; set; }
        public IEnumerable<string> Alerts { get; set; }
        public Error Error { get; set; }
        public Head Head { get; set; }

    }

    public class Policy
    {
        public DateTime From { get; set; }
        public PolicyValueType Type { get; set; }
        public decimal Value { get; set; }
    }


    public class HotelBooking 
    {
        /// <summary>
        /// returned at the time of booking and fetching booking details
        /// </summary>
        public string BookingReference { get; set; }
        /// <summary>
        /// returned at the time of booking and fetching booking details
        /// </summary>
        public string BookingStatus { get; set; }
        /// <summary>
        /// returned at the time of booking and fetching booking details
        /// </summary>
        public string YourReference { get; set; }
        /// <summary>
        /// returned at the time of booking and fetching booking details
        /// </summary>
        public string Currency { get; set; }
        /// <summary>
        /// returned at the time of booking and fetching booking details
        /// </summary>
        public decimal TotalPrice { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public string RequestStatus { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public string PaymentStatus { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public DateTime BookingTime { get; set;}
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public int HotelId { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public string HotelName { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public DateTime CheckInDate { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public DateTime CheckOutDate { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public string LeaderName { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public string Nationality { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public string BoardType { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public DateTime CancellationDeadline { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public IEnumerable<Room> Rooms { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public IEnumerable<Policy> Policies { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public IEnumerable<string> Restrictions { get; set; }
        /// <summary>
        /// returned only when fetching booking details
        /// </summary>
        public IEnumerable<string> Alerts { get; set; }
        public Error Error { get; set; }
        public Head Head { get; set; }
    }


    public class HotelBookingDetails 
    {
        public int BookingsFound { get; set; }
        public int BookingsReturned { get; set; }
        public IEnumerable<HotelBooking> Bookings { get; set; }
        public Error Error { get; set; }
        public Head Head { get; set; }
    }

    public class HotelBookingCancel 
    {
        public string BookingReference { get; set; }
        public string BookingStatus { get; set; }
        public string RequestStatus { get; set; }
        public Error Error { get; set; }
        public Head Head { get; set; }

    }


    public enum PolicyValueType
    {
        Amount,
        Nights,
        Percentage
    }

#    region request objects

    /// <summary>
    /// Atleast one of HotelId or CityId or HotelIds or CityIds is mandatory for seach
    /// </summary>
    public class HotelSearchRequest
    {
        public IEnumerable<int> CityIds { get; set; }
        public IEnumerable<int> HotelIds { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public IEnumerable<Room> Rooms { get; set; }
        public string Nationality { get; set; }
        public string Currency { get; set; }
        public int AvailableOnly { get; set; }
        public int HotelId { get; set; }
        public int CityId { get; set; }
    }


    public class HotelBookingRequest
    {
        public string OptionId { get; set; }
        public string YourReference { get; set; }
        public IEnumerable<RoomRequest> Rooms { get; set; }
    }

    public class RoomRequest
    {
        public string RoomId { get; set; }
        public PaxNames PaxNames { get; set; }

    }

    public class PaxNames
    {
        public IEnumerable<AdultName> AdultName { get; set; }
        public IEnumerable<ChildName> ChildName{ get; set; }
    }


    public class AdultName
    {
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    public class ChildName
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }



    public class HotelBookingDetailsRequest
    {
        public string BookingReference { get; set; }
        public string YourReference { get; set; }
        public BookingDates BookingDates { get; set; }
        public CheckInDates CheckInDates { get; set; }
    }

    public class BookingDates
    {
        public DateTime BookingDateStart { get; set; }
        public DateTime BookingDateEnd { get; set; }
    }

    public class CheckInDates
    {
        public DateTime CheckInDateStart { get; set; }
        public DateTime CheckInDateEnd { get; set; }

    }

    #endregion


}
