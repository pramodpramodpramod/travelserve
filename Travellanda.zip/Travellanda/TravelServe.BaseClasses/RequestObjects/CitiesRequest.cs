﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelServe.BaseClasses.Request
{
    public class HotelsRequest
    {
        public string CountryCode { get; set; }
        public int CityId { get; set; }
        public string CityCode { get; set; }
    }
}
