﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelServe.BaseClasses
{
    public class Error
    {
        public string ErrorText { get; set; }
        public int ErrorId { get; set; }
        public string Message { get; set; }

    }
}
