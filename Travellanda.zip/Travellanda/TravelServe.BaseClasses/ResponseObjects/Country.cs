﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelServe.BaseClasses
{
    public class Countrys
    {
        public int CountriesReturned { get; set; }
        public IEnumerable<Country> Countries { get; set; }
    }

    public class Country
    {
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string Currency { get; set; }
        public IEnumerable<City> Cities { get; set; }
    }

    public class Cities
    {
        public int CitiesReturned { get; set; }
        public IEnumerable<Country> Countries { get; set; }
    }

    public class City
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
        public string StateCode { get; set; }
        public string CityCode { get; set; }
    }


    public class LocationHotels
    {
        public int HotelsReturned { get; set; }
        public IEnumerable<LocationHotel> Hotels { get; set; }
    }   
    public class LocationHotel
    {
        public int HotelId { get; set; }
        public int CityId { get; set; }
        public string CityCode { get; set; }
        public string HotelName { get; set; }
        public string CountryCode { get; set; }
    }
    

    public class HotelDetails
    {
        public int HotelsReturned { get; set; }
        public IEnumerable<Hotel> Hotels { get; set; }
    }

    public class Hotel
    {
        public int HotelId { get; set; }
        public string HotelName { get; set; }
        public string StarRating { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public string Address { get; set; }
        public string Location { get; set; }
        public string PhoneNumber { get; set; }
        public string Description { get; set; }
        public IEnumerable<Facility> Facilities { get; set; }
        public IEnumerable<string> Images { get; set; }
        public IEnumerable<Option> Options { get; set; }
    }

    public class Facility
    {
        public string FacilityType { get; set; }
        public string FacilityName { get; set; }
    }


    public class Option
    {
        public int OptionId { get; set; }
        public int OnRequest { get; set; }
        public string BoardType { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal DiscountApplied { get; set; }
        public string DealName { get; set; }
        public IEnumerable<Room> Rooms { get; set; }
    }

    public class Room
    {
        public string RoomId { get; set; }
        public string RoomName { get; set; }
        public int NumAdults { get; set; }
        public int NumChildren { get; set; }
        public decimal RoomPrice { get; set; }
        public IEnumerable<decimal> DailyPrices { get; set; }
        
    }

    public class HotelSearch
    {
        public IEnumerable<int> CityId { get; set; }
        public IEnumerable<int> HotelIds { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public string Nationality { get; set; }
        public string Currency { get; set; }
        public int HotelsReturned { get; set; }
        public IEnumerable<Hotel> Hotels { get; set; }
    }



    public class HotelPolicies
    {
        public int OptionId { get; set; }
        public string Currency { get; set; }
        public decimal TotalPrice { get; set; }
        public DateTime CancellationDeadline { get; set; }
        public IEnumerable<Policy> Policies { get; set; }

        public IEnumerable<string> Restrictions { get; set; }
        public IEnumerable<string> Alerts { get; set; }

    }

    public class Policy
    {
        public DateTime From { get; set; }
        public PolicyValueType Type { get; set; }
        public decimal Value { get; set; }
    }


    public class HotelBooking
    {
        public string BookingReference { get; set; }
        public string BookingStatus { get; set; }
        public string YourReference { get; set; }
        public string Currency { get; set; }
        public decimal TotalPrice { get; set; }
        public string RequestStatus { get; set; }
        public string PaymentStatus { get; set; }
        public DateTime BookingTime { get; set;}
        public int HotelId { get; set; }
        public int HotelName { get; set; }
        public string City { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public string LeaderName { get; set; }
        public string Nationality { get; set; }
        public string BoardType { get; set; }
        public DateTime CancellationDeadline { get; set; }
        public IEnumerable<Room> Rooms { get; set; }
        public IEnumerable<Policy> Policies { get; set; }
        public IEnumerable<string> Restrictions { get; set; }
        public IEnumerable<string> Alerts { get; set; }

    }


    public class HotelBookingDetails
    {
        public int BookingsFound { get; set; }
        public int BookingsReturned { get; set; }

        public IEnumerable<Booking> Bookings { get; set; }


    }

    public class Booking
    {
        public IEnumerable<HotelBooking> HotelBooking { get; set; }
    }

    public class HotelBookingCancel
    {
        public string BookingReference { get; set; }
        public string BookingStatus { get; set; }
        public string RequestStatus { get; set; }
    }


    public enum PolicyValueType
    {
        Amount,
        Nights,
        Percentage
    }

    #region request objects

    public class PaxNames
    {
        public IEnumerable<AdultName> AdultName { get; set; }
        public IEnumerable<ChildName> ChildName{ get; set; }
    }


    public class AdultName
    {
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    public class ChildName
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
    #endregion


}
