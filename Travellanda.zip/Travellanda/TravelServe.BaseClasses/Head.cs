﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelServe.BaseClasses
{
    public class Head
    {
        public DateTime ServerTime { get; set; }
        public string ServerType { get; set; }
        public string ResponseType { get; set; }
        public decimal ExecutionTime { get; set; }
    }
}