﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services.Description;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace Travelanda
{
    public class XmlGenerator<T> where T: class
    {
        public XmlGenerator()
        {
        }


        private string postXMLData(string destinationUrl, string requestXml)
        {
            //var client = new HttpClient();
            //client.BaseAddress = new Uri(destinationUrl);
            //StringContent content = new StringContent(requestXml);
            //HttpRequestMessage msg = new HttpRequestMessage(HttpMethod.Post, destinationUrl);
            //msg.Content = content;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(destinationUrl);
            byte[] bytes;
            bytes = System.Text.Encoding.ASCII.GetBytes(requestXml);
            request.ContentType = "text/xml; encoding='utf-8'";
            request.ContentLength = bytes.Length;
            request.Method = "POST";
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(bytes, 0, bytes.Length);
            requestStream.Close();
            HttpWebResponse response;
            response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream responseStream = response.GetResponseStream();
                string responseStr = new StreamReader(responseStream).ReadToEnd();
                return responseStr;
            }
            return null;
        }

        public string Submit(T xmlObject)
        {
            var url = "http://xmldemo.travellanda.com/xmlv1";
            var postData = getXMLString(xmlObject);
            return postXMLData(url, postData);
        }



        private string getXMLString(T xmlObject)
        {

            if (xmlObject == null)
            {
                return string.Empty;
            }
            try
            {
                var xmlserializer = new XmlSerializer(typeof(T));
                var stringWriter = new StringWriter();
                using (var writer = XmlWriter.Create(stringWriter))
                {
                    xmlserializer.Serialize(writer, xmlObject);
                    return stringWriter.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred", ex);
            }
        }

    }
}
